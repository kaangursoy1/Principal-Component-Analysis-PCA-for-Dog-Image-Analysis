# -*- coding: utf-8 -*-
"""
Created on Sun Dec  4 22:48:58 2022

@author: kaang
"""

import numpy as np
import pandas as pd
import math
import seaborn as sns
from tqdm import tqdm
import matplotlib.pyplot as plt
plain_data = pd.read_csv("dataset.csv")


train_data = plain_data.sample(frac=0.7, random_state=25)
test_data = plain_data.sample(frac=0.2, random_state=25)
val_data = data = plain_data.sample(frac=0.1, random_state=25)


my_data = (train_data - train_data.min())/(train_data.max()-train_data.min())
