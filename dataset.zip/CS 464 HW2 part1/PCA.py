# -*- coding: utf-8 -*-
"""
Created on Sat Dec  3 19:29:10 2022

@author: Kaan Gursoy
"""
import numpy as np
import glob
import seaborn as sb
import matplotlib.pyplot as plt
import PIL 
import matplotlib.image as image
from PIL import Image
x=2
k=2
image_list=[]
#CONVERTING 512X512 TO 64X64
for i in range(5239):
    if x<10:
        image = Image.open('flickr_dog_00000'+str(x)+'.jpg')
        new_image = image.resize((64, 64))
        new_image.save('flickr_dog_00000'+str(x)+'.jpg')
    elif x >=10 and x<100:
        image = Image.open('flickr_dog_0000'+str(x)+'.jpg')
        new_image = image.resize((64, 64))
        new_image.save('flickr_dog_0000'+str(x)+'.jpg')
    elif x >=100 and x<1000:
        image = Image.open('flickr_dog_000'+str(x)+'.jpg')
        new_image = image.resize((64, 64))
        new_image.save('flickr_dog_000'+str(x)+'.jpg')
    elif x >=1000 and x<=1183:
        image = Image.open('flickr_dog_00'+str(x)+'.jpg')
        new_image = image.resize((64, 64))
        new_image.save('flickr_dog_00'+str(x)+'.jpg')

    elif x>=1184:
        if k<10:
            image = Image.open('pixabay_dog_00000'+str(k)+'.jpg')
            new_image = image.resize((64, 64))
            new_image.save('pixabay_dog_00000'+str(k)+'.jpg')
            
        elif k >=10 and k<100:
            image = Image.open('pixabay_dog_0000'+str(k)+'.jpg')
            new_image = image.resize((64, 64))
            new_image.save('pixabay_dog_0000'+str(k)+'.jpg')
        elif k >=100 and k<1000:
            image = Image.open('pixabay_dog_000'+str(k)+'.jpg')
            new_image = image.resize((64, 64))
            new_image.save('pixabay_dog_000'+str(k)+'.jpg')
        elif k >=1000 and k<4059:
            image = Image.open('pixabay_dog_00'+str(k)+'.jpg')
            new_image = image.resize((64, 64))
            new_image.save('pixabay_dog_00'+str(k)+'.jpg')
        k+=1
    x+=1
    dog_data = list(new_image.getdata())
    image_list.append(dog_data)

imarray = np.array(image_list)
red = imarray[:,:,0]
green = imarray[:,:,1]
blue = imarray[:,:,2]
   
def PCA(X , number):
     
    u = np.mean(X, axis = 0)

    u_matrix = X - np.mean(X , axis = 0)
     
    covariance = np.cov(u_matrix , rowvar = False)
     
    eigenvalues , eigenvectors = np.linalg.eigh(covariance)
     
    a = np.argsort(eigenvalues)[::-1]
    b = eigenvalues[a]
    c = eigenvectors[:,a]
     
    d = c[:,0:number]
    e = np.dot(d.transpose() , u_matrix.transpose() ).transpose()


    f = [i/np.sum(eigenvalues) for i in b[:number]]
     
    return e, f, d, u   

print("Proportion of variance explained Red sum for 10 PC", np.sum(PCA(red,10)[1]))
print("Proportion of variance explained Green sum for 10 PC", np.sum(PCA(green,10)[1]))
print("Proportion of variance explained Blue sum for 10 PC", np.sum(PCA(blue,10)[1]))

print("Proportion of variance explained Red sum for 20 PC", np.sum(PCA(red,20)[1]))
print("Proportion of variance explained Green sum for 20 PC", np.sum(PCA(green,20)[1]))
print("Proportion of variance explained Blue sum for 20 PC", np.sum(PCA(blue,20)[1]))













